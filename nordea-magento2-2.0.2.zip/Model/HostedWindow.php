<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Model;

use Magento\Directory\Helper\Data as DirectoryHelper;
use Magento\Payment\Model\InfoInterface;

/**
 * Hosted Window model
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class HostedWindow extends \Magento\Payment\Model\Method\AbstractMethod
{
    /**
     * Payment method code
     *
     * @var string
     */
    protected $_code = 'psp_hostedwindow';

    /**
     * @var string
     */
    protected $_formBlockType = \Magento\OfflinePayments\Block\Form\Checkmo::class;

    /**
     * @var string
     */
    protected $_infoBlockType = \NordeaConnect\Magento\Block\Info\HostedWindowBlock::class;

    /**
     * Payment Method feature
     *
     * @var bool
     */
    protected $_canCapture = true;

    /**
     * Payment Method feature
     *
     * @var bool
     */
    protected $_canCapturePartial = true;

    /**
     * Payment Method feature
     *
     * @var bool
     */
    protected $_canRefund = true;

    /**
     * Payment Method feature
     *
     * @var bool
     */
    protected $_canRefundInvoicePartial = true;

    /**
     * Payment Method feature
     *
     * @var bool
     */
    protected $_canUseCheckout = true;

    /**
     * Nordea Connect API wrapper for transactions
     *
     * @var \NordeaConnect\Magento\Model\Api\Transaction
     */
    protected $transaction;

    /**
     * HostedWindow constructor.
     *
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
     * @param \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory
     * @param \Magento\Payment\Helper\Data $paymentData
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Payment\Model\Method\Logger $logger
     * @param \NordeaConnect\Magento\Model\Api\Transaction $transaction
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        \NordeaConnect\Magento\Model\Api\Transaction $transaction,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = [],
        DirectoryHelper $directory = null
    ) {
        $this->transaction = $transaction;
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            $resource,
            $resourceCollection,
            $data,
            $directory
        );
    }

    /**
     * Authorize
     *
     * @param \Magento\Framework\DataObject|InfoInterface $payment Payment
     * @param float                                       $amount  Amount
     *
     * @return $this
     */
    public function authorize(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        return $this;
    }

    /**
     * Order payment
     *
     * @param \Magento\Framework\DataObject|InfoInterface $payment Payment
     * @param float                                       $amount  Amount
     *
     * @return $this
     */
    public function order(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        return $this;
    }

    /**
     * Capture payment
     *
     * @param \Magento\Framework\DataObject|InfoInterface $payment Payment
     * @param float                                       $amount  Amount
     *
     * @return $this
     */
    public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $order = $payment->getOrder();
        $result = $this->transaction->capture($order, $amount);
        $result = json_decode($result);

        if (is_object($result) && property_exists($result, 'code')) {
            $message = sprintf(
                __("Nordea Connect returned error code %d: %s (%s)"),
                $result->code,
                $result->description,
                $result->name
            );
            throw new \Magento\Framework\Exception\LocalizedException(__($message));
        }

        if (!is_object($result) || (is_object($result) && !property_exists($result, 'id'))) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Could not capture order online'));
        }

        $payment->setTransactionId($result->id)->setIsTransactionClosed(false);
        $payment->setAdditionalInformation('id', $result->id);
        $payment->setAdditionalInformation('href', $result->href);
        $payment->setAdditionalInformation('status', $result->status);

        return true;
    }

    /**
     * Refund specified amount for payment
     *
     * @param \Magento\Framework\DataObject|InfoInterface $payment Payment
     * @param float                                       $amount  Amount
     *
     * @return $this
     */
    public function refund(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $captureTxnId = $payment->getParentTransactionId();

        if (!$captureTxnId) {
            throw new \Magento\Framework\Exception\LocalizedException(
                __('We can\'t issue a refund transaction because there is no capture transaction.')
            );
        }

        $order = $payment->getOrder();

        $canRefundMore = $payment->getCreditmemo()->getInvoice()->canRefund();
        $isFullRefund = !$canRefundMore &&
                0 == (double)$order->getBaseTotalOnlineRefunded() + (double)$order->getBaseTotalOfflineRefunded();

        $result = $this->transaction->refund($order, $amount);
        $result = json_decode($result);

        if (property_exists($result, 'code') && $result->code != 200) {
            $message = sprintf(
                __("Nordea Connect returned error code %d: %s (%s)"),
                $result->code,
                $result->description,
                $result->name
            );

            throw new \Magento\Framework\Exception\LocalizedException(__($message));
        }

        $payment->setTransactionId($result->id)
            ->setIsTransactionClosed(1)
            ->setShouldCloseParentTransaction(!$canRefundMore);

        return $this;
    }

    /**
     * Void payment
     *
     * @param \Magento\Framework\DataObject|InfoInterface $payment Payment
     *
     * @return $this
     */
    public function void(\Magento\Payment\Model\InfoInterface $payment)
    {
        return $this;
    }

    /**
     * Attempt to accept a payment that is under review
     *
     * @param InfoInterface $payment Payment information
     *
     * @return false
     */
    public function acceptPayment(InfoInterface $payment)
    {
        return false;
    }

    /**
     * Attempt to deny a payment that is under review
     *
     * @param InfoInterface $payment Payment information
     *
     * @return false
     */
    public function denyPayment(InfoInterface $payment)
    {
        return false;
    }

    /**
     * Retrieve information from payment configuration
     *
     * @param string                                     $field   Field in configuration
     * @param int|string|null|\Magento\Store\Model\Store $storeId Store ID
     *
     * @return mixed
     */
    public function getConfigData($field, $storeId = null)
    {
        if ('order_place_redirect_url' === $field) {
            return $this->getOrderPlaceRedirectUrl();
        }
        if (null === $storeId) {
            $storeId = $this->getStore();
        }
        $path = 'payment/psp/' . $field;

        return $this->_scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);
    }
}
