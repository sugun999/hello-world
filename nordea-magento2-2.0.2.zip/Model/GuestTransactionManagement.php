<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Model;

use NordeaConnect\Magento\Api\GuestTransactionManagementInterface;
use NordeaConnect\Magento\Model\Api\Transaction;
use Magento\Quote\Model\QuoteIdMaskFactory;

/**
 * Transaction management model
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class GuestTransactionManagement implements GuestTransactionManagementInterface
{
    protected $transaction;
    protected $quoteIdMaskFactory;

    /**
     * Constructor
     *
     * @param NordeaConnect\Magento\Model\Api\Transaction  $transaction        Nordea Connect transaction API model
     * @param Magento\Quote\Model\QuoteIdMaskFactory $quoteIdMaskFactory Quote ID mask factory
     *
     * @return void
     */
    public function __construct(Transaction $transaction, QuoteIdMaskFactory $quoteIdMaskFactory)
    {
        $this->transaction = $transaction;
        $this->quoteIdMaskFactory = $quoteIdMaskFactory;
    }

    /**
     * Update
     *
     * Takes the quote and updates the transaction at Nordea Connect and returns the JSON response.
     *
     * @param string $cartId Masked quote identifier
     *
     * @return string
     */
    public function update($cartId)
    {
        $quoteIdMask = $this->quoteIdMaskFactory->create()->load($cartId, 'masked_id');

        return $this->transaction->update($quoteIdMask->getQuoteId());
    }
}
