<?php
namespace NordeaConnect\Magento\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Escaper;
use Magento\Payment\Helper\Data as PaymentHelper;

class HostedWindowConfigProvider implements ConfigProviderInterface
{
    private $config;

    public function __construct(Config $config)
    {
        $this->config = $config;
    }
    /**
     * {@inheritdoc}
     */
    public function getConfig()
    {
        return [
            'payment' => [
                'whitelabelmodulenamespace' => [
                    'logos' => explode(',', $this->config->getPaymentLogos()),
                ],
            ],
        ];
    }
}
