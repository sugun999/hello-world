<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Model;

use NordeaConnect\Magento\Api\TransactionManagementInterface;
use NordeaConnect\Magento\Model\Api\Transaction;
use Magento\Quote\Api\CartRepositoryInterface;

/**
 * Transaction management model
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class TransactionManagement implements TransactionManagementInterface
{
    protected $transaction;
    protected $cartRepository;

    /**
     * Constructor
     *
     * @param NordeaConnect\Magento\Model\Api\Transaction     $transaction    Nordea Connect transaction API model
     * @param Magento\Quote\Api\CartRepositoryInterface $cartRepository Cart repository
     *
     * @return void
     */
    public function __construct(Transaction $transaction, CartRepositoryInterface $cartRepository)
    {
        $this->transaction = $transaction;
        $this->cartRepository = $cartRepository;
    }

    /**
     * Update
     *
     * Takes the quote and updates the transaction at Nordea Connect and returns the JSON response.
     *
     * @param id $cartId Quote identifier
     *
     * @return string
     */
    public function update($cartId)
    {
        $quote = $this->cartRepository->get($cartId);

        return $this->transaction->update($quote);
    }
}
