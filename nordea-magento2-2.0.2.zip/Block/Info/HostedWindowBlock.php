<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Block\Info;

use Magento\Payment\Block\Info;
use Magento\Sales\Block\Adminhtml\Order\Payment as AdminPaymentBlock;

/**
 * Hosted Window info block
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class HostedWindowBlock extends Info
{
    /**
     * Constructor
     *
     * @param \Magento\Framework\View\Element\Template\Context $context     Context
     * @param \NordeaConnect\Magento\Model\Api\Transaction           $transaction Transaction API model
     * @param array                                            $data        Data
     *
     * @return void
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \NordeaConnect\Magento\Model\Api\Transaction $transaction,
        array $data = []
    ) {
        $this->transaction = $transaction;
        parent::__construct($context, $data);
    }

    /**
     * Prepare specific information
     *
     * @param null|\Magento\Framework\DataObject|array $transport Information
     *
     * @return \Magento\Framework\DataObject
     */
    protected function _prepareSpecificInformation($transport = null)
    {
        if (null !== $this->_paymentSpecificInformation) {
            return $this->_paymentSpecificInformation;
        }

        $transport = new \Magento\Framework\DataObject();
        $transaction = $this->transaction->show($this->getInfo()->getAdditionalInformation('id'));
        $data = json_decode($transaction, true);

        if (array_key_exists('id', $data)) {
            if ($this->isAdminBlock()) {
                $this->addAdminFacingInformation($data, $transport);
            } else {
                $this->addCustomerFacingInformation($data, $transport);
            }
        }

        return parent::_prepareSpecificInformation($transport);
    }

    private function addAdminFacingInformation($data, &$transport)
    {
        $transport->setData('ID', $data['id']);
        $transport->setData('Reference', $data['payment_ref']);
        $transport->setData('Status', $data['status']);
        $transport->setData('Payment method', $data['transaction_type']);
        $transport->setData('Card type', $data['payment_details']['card_type']);
        $transport->setData('Card number', $data['payment_details']['card_number']);
        $transport->setData('Card holder', $data['payment_details']['card_holder']);
        $transport->setData('MPI ref', $data['mpi_ref']);
        $transport->setData('SSN', $data['payment_details']['ssn']);

        $gender = '';

        if (strtolower($data['payment_details']['country_code']) == 'swe' &&
            strtolower($data['payment_details']['segmentation']) == 'b2c' &&
            $data['payment_details']['ssn']) {
            $genderCheck = substr($data['payment_details']['ssn'], -2, 1);
            $gender = ($genderCheck % 2) ? 'Male' : 'Female';
        }

        $transport->setData('Gender', $gender);
        $transport->setData('Currency', strtoupper($data['currency']));
        $transport->setData('Payment link', $data['href']);
        $transport->setData('Created at', $data['created_at']);
        $transport->setData('Processed at', $data['processed_at']);
    }

    private function addCustomerFacingInformation($data, &$transport)
    {
        $transport->setData('Status', $data['status']);
        $transport->setData('Payment method', $data['transaction_type']);
        $transport->setData('Card type', $data['payment_details']['card_type']);
        $transport->setData('Card number', $data['payment_details']['card_number']);
        $transport->setData('Card holder', $data['payment_details']['card_holder']);
    }

    private function isAdminBlock()
    {
        return $this->getParentBlock() && $this->getParentBlock() instanceof AdminPaymentBlock;
    }
}
