<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Customer\Model\AddressFactory;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Message\ManagerInterface;
use Magento\Framework\Notification\MessageInterface;
use NordeaConnect\Magento\Model\Api\Transaction;
use NordeaConnect\Magento\Model\Config;

/**
 * Checkout predispatch observer
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class CheckoutPredispatchObserver implements ObserverInterface
{
    protected $transaction;
    protected $messageManager;
    protected $addressFactory;
    protected $scopeConfig;
    protected $inboxFactory;
    protected $config;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $urlInterface;

    /**
     * Constructor
     *
     * @param \NordeaConnect\Magento\Model\Api\Transaction             $transaction    Transaction API model
     * @param \Magento\Framework\Message\ManagerInterface        $messageManager Message manager
     * @param \Magento\Customer\Model\AddressFactory             $addressFactory Cusomter address factory
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig    Scope config
     * @param \Magento\Framework\UrlInterface                    $urlInterface    Url interface
     *
     * @return void
     */
    public function __construct(
        Transaction $transaction,
        ManagerInterface $messageManager,
        AddressFactory $addressFactory,
        ScopeConfigInterface $scopeConfig,
        \Magento\Framework\UrlInterface $urlInterface,
        \Magento\AdminNotification\Model\InboxFactory $inboxFactory,
        Config $config
    ) {
        $this->urlInterface = $urlInterface;
        $this->transaction = $transaction;
        $this->messageManager = $messageManager;
        $this->addressFactory = $addressFactory;
        $this->scopeConfig = $scopeConfig;
        $this->inboxFactory = $inboxFactory;
        $this->config = $config;
    }

    /**
     * Execute
     *
     * @param \Magento\Framework\Event\Observer $observer Observer object
     *
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $quote = $observer->getEvent()->getControllerAction()->getOnepage()->getQuote();

        $customer = $quote->getCustomer();

        $allowedCountries = explode(
            ',',
            $this->scopeConfig->getValue(
                'general/country/allow',
                \Magento\Store\Model\ScopeInterface::SCOPE_WEBSITE
            )
        );
        $defaultCountry = $this->scopeConfig->getValue(
            'general/country/default',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );

        $forceDefaultCountry = true;

        if ($customer->getId() && $this->config->getPaymentMode() === 'checkout') {
            $addressId = $customer->getDefaultShipping();
            $address = $this->addressFactory->create()->load($addressId)->getDataModel();

            $quote->getShippingAddress()->importCustomerAddressData($address);
            $quote->getBillingAddress()->importCustomerAddressData($address);

            if (in_array($address->getCountryId(), $allowedCountries)) {
                $forceDefaultCountry = false;
            }
        }

        $shippingAddress = $quote->getShippingAddress('shipping');

        if ($forceDefaultCountry == true) {
            if (!$shippingAddress->getCountryId()) {
                $shippingAddress->setCountryId($defaultCountry)->save();
            }
        }

        if (!$shippingAddress->getShippingMethod()) {
            $shippingAddress->setCollectShippingRates(true)
                ->collectShippingRates()
                ->setShippingMethod($this->getDefaultShippingMethodCode($shippingAddress));
            $quote->collectTotals()->save();
        }

        if ($quote->getId()) {
            if (!$quote->getPspTransaction()) {
                $response = $this->transaction->create($quote);
            } else {
                $response = $this->transaction->update($quote);
            }

            if ($response) {
                $data = json_decode($response);
                $error_url = $this->urlInterface->getUrl('checkout/cart');

                if (!is_object($data)) {

                    $this->messageManager->addError(__('Something went wrong'));

                    $this->inboxFactory->create()->parse([[
                        'severity' => MessageInterface::SEVERITY_CRITICAL,
                        'date_added' => (string) (new \DateTime())->format(\DateTimeInterface::ATOM),
                        'title' => sprintf(__('Nordea Connect returned an invalid response when trying to create/update transaction for quote %d'), $quote->getId()),
                        'description' => sprintf(__('Response: %s'), $response),
                    ]]);

                    $observer->getControllerAction()->getResponse()->setRedirect($error_url);
                } elseif (!property_exists($data, 'id')) {
                    $this->inboxFactory->create()->parse([[
                        'severity' => MessageInterface::SEVERITY_CRITICAL,
                        'date_added' => (string) (new \DateTime())->format(\DateTimeInterface::ATOM),
                        'title' => sprintf(__('Nordea Connect returned an error when trying to create/update transaction for quote %d'), $quote->getId()),
                        'description' => sprintf(__('Code: %d, Error: %s Error description %s'), $data->code, $data->name, $data->description),
                    ]]);

                    $this->messageManager->addError(__('Something went wrong'));

                    $observer->getControllerAction()->getResponse()->setRedirect($error_url);
                } else {
                    /**
                     * Remove the ever growing log events from the transaction response
                     * to avoid hitting the 64k limit of the MySQL text field that will
                     * hold the data
                     */
                    if (property_exists($data, 'log_events')) {
                        $data->log_events = __("Please login to your Nordea Connect account to see the log events.");
                    }

                    $response = json_encode($data);

                    $quote->setPspTransaction($response);
                    $quote->save();

                    if ($this->config->getPaymentView() === 'redirect') {
                        $observer->getControllerAction()->getResponse()->setRedirect($data->href);
                    }
                }
            }
        }
    }

    private function getDefaultShippingMethodCode($shippingAddress)
    {
        $rate = $shippingAddress
            ->setCollectShippingRates(true)
            ->collectShippingRates()
            ->getShippingRatesCollection()
            ->getFirstItem()->toArray();

        return array_key_exists('code', $rate) ? $rate['code'] : 'flatrate_flatrate';
    }
}
