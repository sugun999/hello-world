define([
    'jquery',
    'Magento_Checkout/js/view/payment/default',
    'Magento_Paypal/js/action/set-payment-method',
    'Magento_Checkout/js/model/payment/additional-validators',
    'mage/url'
], function ($, Component, setPaymentMethodAction, additionalValidators, url) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'NordeaConnect_Magento/payment/psp-hosted'
        },
        getLogoSrc: function() {
            return require.toUrl('NordeaConnect_Magento/images/logo/nordeaconnect.png');
        },
        getRenderedPaymentLogos: function() {
            return window.checkoutConfig.payment.whitelabelmodulenamespace.logos.map(function(item) {
                return '<img style="margin:5px" src="' + require.toUrl('NordeaConnect_Magento/images/paymentoptions/' + item) + '" alt="'+item+'" />';
            }).join('');
        },
        placeTransaction: function() {
            if (!additionalValidators.validate()) {
                return false;
            }
            this.selectPaymentMethod();
            setPaymentMethodAction(this.messageContainer).done(function () {
                $.mage.redirect(url.build('psp/checkout'));
            });
        }
    });
});
