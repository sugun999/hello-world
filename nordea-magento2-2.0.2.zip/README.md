Nordea Connect payments
==============================
Magento 2 module version 2.0.2

The Nordea Connect Magento 2 module supports multiple payment methods such as Cards, Invoice, Direct Bank, PayPal and Swish.

## Configuration of Module

To configure the module, you can find it in your administration panel. 

1.Go to: Stores – Configuration

![Step 1](Screenshots/screenshot1.png)

2.Go to: Sales – Payment Methods

![Step 2](Screenshots/screenshot2.png)

3.Scroll down to the bottom and activate by configure 

![Step 3](Screenshots/screenshot3.png)

4.If you already has an account for your payment, you can login to get this settings. If you don’t have any, you can sign up for an new account.

![Step 4](Screenshots/screenshot4.png)
Enable this Solution: Yes [Active] _or_ No [Not active] 
                      
Merchant ID: Your identification for your shop, this will be given to you by your Payment Provider

Create the directory `app/code/NordeaConnect/Magento` and place the content of this zip-file into that directory.

Then run the following commands to enable the module

```
bin/magento module:enable NordeaConnect_Magento
bin/magento setup:upgrade
bin/magento setup:static-content:deploy
bin/magento setup:di:compile
```

## Limitations

API Password: You will find this through your payment provider, this will be given to you by your Payment Provider

Secret: You will find this through your payment provider, this will be given to you by your Payment Provider

Test Mode: Yes [Shall be active if you want to test your payment function. The use of test cards is only allowed]
           No [Shall not be active if you don’t allow testing your payment function]
           
Payment Action: Authorize - Money will be reserved
                Authorize and Capture - Money will be captured instantly
                
Email webhook failures to: E-mail address for all information about failed payments

Address information will be collected by Nordea Connect Payments in the embedded iframe and sent to Magento in a webhook. Any information missing when the order is supposed to be created in the webhook needs to be fixed in the iframe first.

### Shipping methods

For now, the only supported shipping method is the flat rate shipping method. Use shopping cart promotions if free shipping is needed.

### Tracking on success page

We can't guarantee that the webhook has fired and that the order has been created when the customer reaches the success page. Instead of tracking data from the order object, try tracking information directly from the quote.

### Partial capturing

Partial capturing will be added in a future version when the Nordea Connect API supports it.

## Support

Please, feel free to create issues on our GitHub repository. Contact support@nordeaconnect.zendesk.com if you have specific problems for your account.
