<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Test\Unit\Block;

use NordeaConnect\Magento\Test\Unit\PaymentPspObjectManager as ObjectManager;
use PHPUnit_Framework_MockObject_MockObject as MockObject;

/**
 * RegistrationTest
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class RegistrationTest extends \PHPUnit\Framework\TestCase
{
    /**
     * @var \Magento\Framework\TestFramework\Unit\Helper\ObjectManager
     */
    protected $objectManager;

    /**
     * @var \NordeaConnect\Magento\Block\Registration | MockObject
     */
    protected $registrationMock;

    /**
     * Set up
     *
     * @return void
     */
    protected function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->registrationMock = $this->getMockBuilder(
            \NordeaConnect\Magento\Block\Registration::class)
            ->setMethodsExcept(['toHtml'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    /**
     * Test toHtml method
     *
     * @return void
     */
    public function testToHtml()
    {
        $this->assertEquals('', $this->registrationMock->toHtml());
    }

    /**
     * Tear down
     *
     * @return void
     */
    protected function tearDown()
    {
        $this->objectManager = null;
        $this->registrationMock = null;
    }
}
