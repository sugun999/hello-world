# Changelog

## [2.0.2] - 2020-04-28
### Fixed
- Use the correct currency on order
- Remove print receipt link

## [2.0.1] - 2020-04-28
### Fixed
- Make autcaptured payments refundable
- Update payment_details on transaction update
- Do not update email on order if its empty in payment_details

## [2.0.0] - 2020-04-27
### Added
- Hosted window
### Fixed
- Replace all placeholders to have valid php code
- Fix callback error on siirto payments

## [1.0.8] - 2020-03-24
### Added
- Send notice to admin if there is something wrong with creating or updating transactions

## [1.0.7] - 2020-03-16
### Fixed
- Remove title over checkout iframe

## [1.0.6] - 2020-02-20
### Fixed
- Force active quotes to be inactive after 5 minutes when receiving payment webhooks

### Added
- Add checkout mode to metadata

## [1.0.5] - 2019-12-13
### Fixed
- Resize payment iframe when the content changes
- Do not create multiple orders from the same quote

## [1.0.4] - 2019-11-26
### Added
- Show a scroll bar when the content is larger than the iframe in checkout

## [1.0.3] - 2019-11-19
### Added
- Dispatch 'checkout_submit_all_after' after order is created

### Fixed
- Handle new transactions that are already capured.


## [1.0.2] - 2019-11-07
### Changed
- Only use a subset of the payment details when sending confirmation email.

### Fixed
- Fix crash when trying to send confirmation email.


## [1.0.1] - 2019-11-05
### Changed
- Get shipping method from available shipping rates instead of hard coding flatrate

### Fixed
- Handle new transactions that are already capured.


## [1.0.0] - 2019-10-29
### Added
- new version of the plugin

### Removed

### Changed

