<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Controller\Checkout;

/**
 * Success action
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class Success extends \NordeaConnect\Magento\Controller\Checkout\Index
{
    /**
     * @param $context
     * @param $customerSession
     * @param \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository
     * @param \Magento\Customer\Api\AccountManagementInterface $accountManagement
     * @param $coreRegistry
     * @param $translateInline
     * @param $formKeyValidator
     * @param $scopeConfig
     * @param $layoutFactory
     * @param $quoteRepository
     * @param $resultPageFactory
     * @param $resultLayoutFactory
     * @param $resultRawFactory
     * @param $resultJsonFactory
     * @param \Magento\Checkout\Helper\Data $checkoutHelper
     * @param \Magento\Checkout\Model\Session $checkoutSession
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
        \Magento\Customer\Api\AccountManagementInterface $accountManagement,
        \Magento\Framework\Registry $coreRegistry,
        \Magento\Framework\Translate\InlineInterface $translateInline,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\View\LayoutFactory $layoutFactory,
        \Magento\Quote\Api\CartRepositoryInterface $quoteRepository,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory,
        \Magento\Framework\Controller\Result\RawFactory $resultRawFactory,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \NordeaConnect\Magento\Model\Config $modelConfig,
        \Magento\Checkout\Helper\Data $checkoutHelper,
        \Magento\Checkout\Model\Session $checkoutSession
    ) {
        parent::__construct(
            $context,
            $customerSession,
            $customerRepository,
            $accountManagement,
            $coreRegistry,
            $translateInline,
            $formKeyValidator,
            $scopeConfig,
            $layoutFactory,
            $quoteRepository,
            $resultPageFactory,
            $resultLayoutFactory,
            $resultRawFactory,
            $resultJsonFactory,
            $modelConfig,
            $checkoutHelper,
            $checkoutSession
        );
    }

    /**
     * Execute
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $session = $this->getOnepage()->getCheckout();

        $session->clearQuote();
        $resultPage = $this->resultPageFactory->create();
        $this->_eventManager->dispatch(
            'checkout_onepage_controller_success_action',
            ['order_ids' => [$session->getLastOrderId()]]
        );
        return $resultPage;
    }
}
