<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Model\Adminhtml\Source;

use Magento\Payment\Model\Method\AbstractMethod;
use Magento\Framework\Option\ArrayInterface;

/**
 * Payment logos source model
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class PaymentLogos implements ArrayInterface
{
    /**
     * To option array
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'Visa.png', 'label' => 'Visa'],
            ['value' => 'MasterCard.png', 'label' => 'MasterCard'],
            ['value' => 'American-Express.png', 'label' => 'American Express'],
            ['value' => 'Diners-Club.png', 'label' => 'Diners Club'],
            ['value' => 'Dankort.png', 'label' => 'Dankort'],

            ['value' => 'Swish.png', 'label' => 'Swish'],
            ['value' => 'Vipps.png', 'label' => 'Vipps'],
            ['value' => 'MobilePay.png', 'label' => 'MobilePay'],
            ['value' => 'PayPal.png', 'label' => 'PayPal'],
            ['value' => 'Siirto.png', 'label' => 'Siirto'],

            ['value' => 'Nordea.png', 'label' => 'Nordea'],
            ['value' => 'OP.png', 'label' => 'OP'],
            ['value' => 'Spankki.png', 'label' => 'Spankki'],
            ['value' => 'Alandsbanken.png', 'label' => 'Ålandsbanken'],
            ['value' => 'Danskebank.png', 'label' => 'Danskebank'],
            ['value' => 'Omaspankki.png', 'label' => 'Omaspankki'],
            ['value' => 'PopPankki.png', 'label' => 'POP Pankki'],
            ['value' => 'Saastopankki.png', 'label' => 'Säästopankki'],

            ['value' => 'AfterPay.png', 'label' => 'AfterPay'],
        ];
    }
}
