<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Test\Unit\Helper;

use NordeaConnect\Magento\Test\Unit\PaymentPspObjectManager as ObjectManager;
use PHPUnit_Framework_MockObject_MockObject as MockObject;

/**
 * Data helper test
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class DataTest extends \PHPUnit\Framework\TestCase
{
    /**
     * @var \Magento\Framework\TestFramework\Unit\Helper\ObjectManager
     */
    protected $objectManager;

    /** @var \NordeaConnect\Magento\Helper\Data | MockObject */
    protected $dataMock;

    /**
     * Set up
     *
     * @return void
     */
    protected function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->dataMock = $this->getMockBuilder(\NordeaConnect\Magento\Helper\Data::class)
            ->setMethodsExcept(['formatNumber'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    /**
     * Success test for formatNumber method ( method - formatNumber )
     */
    public function testFormatNumber()
    {
        $this->assertEquals(
            number_format(
                5000, 2, '.', ''
            ),
            $this->dataMock->formatNumber(
                5000, 2, '.', ''
            )
        );
    }

    /**
     * Tear down
     *
     * @return void
     */
    protected function tearDown()
    {
        $this->objectManager = null;
    }
}
