<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Test\Unit\Observer;

use NordeaConnect\Magento\Test\Unit\PaymentPspObjectManager as ObjectManager;
use PHPUnit_Framework_MockObject_MockObject as MockObject;

/**
 * Observer test
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class QuoteSubmitBeforeObserverTest extends \PHPUnit\Framework\TestCase
{
    /** @var \NordeaConnect\Magento\Test\Unit\PaymentPspObjectManager */
    protected $objectManager;

    /** @var \NordeaConnect\Magento\Observer\QuoteSubmitBeforeObserver | MockObject */
    protected $quoteSubmitBeforeObserverMock;

    /** @var \Magento\Framework\Event\Observer | MockObject */
    protected $observerMock;

    /** @var \Magento\Quote\Model\Quote | MockObject */
    protected $quoteMock;

    /** @var \Magento\Sales\Model\Order | MockObject */
    protected $orderMock;

    /**
     * Set up
     *
     * @return void
     */
    public function setUp()
    {
        $this->objectManager = new ObjectManager($this);

        $this->quoteSubmitBeforeObserverMock = $this->objectManager->getObject(\NordeaConnect\Magento\Observer\QuoteSubmitBeforeObserver::class);

        $this->observerMock = $this->getMockBuilder(\Magento\Framework\Event\Observer::class)
            ->setMethods(['getQuote','getOrder'])
            ->disableOriginalConstructor()
            ->getMock();
        $this->quoteMock = $this->getMockBuilder(\Magento\Quote\Model\Quote::class)
            ->setMethods(['getPspTransaction'])
            ->disableOriginalConstructor()
            ->getMock();
        $this->orderMock = $this->objectManager->getObject(\Magento\Sales\Model\Order::class);
    }

    /**
     * Test execute()
     *
     * @return void
     */
    public function testExecute()
    {
        $this->quoteMock->method('getPspTransaction')->willReturn('string');
        $this->observerMock->method('getQuote')->willReturn($this->quoteMock);
        $this->observerMock->method('getOrder')->willReturn($this->orderMock);
        $this->quoteSubmitBeforeObserverMock->execute($this->observerMock);
        $this->assertEquals('string',$this->orderMock->getPspTransaction());
    }

    /**
     * tearDown f
     */
    public function tearDown()
    {
        $this->objectManager = null;
        $this->observerMock = null;
        $this->quoteMock = null;
        $this->orderMock = null;
        $this->quoteSubmitBeforeObserverMock = null;

    }
}
