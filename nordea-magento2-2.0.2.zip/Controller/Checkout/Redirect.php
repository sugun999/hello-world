<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Controller\Checkout;

/**
 * Redirect action
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class Redirect extends \Magento\Checkout\Controller\Onepage
{
    /**
     * Execute
     *
     * @return void
     */
    public function execute()
    {
        // Get session
        $session = $this->getOnepage()->getCheckout();

        // Get quote
        $quote = $this->getOnepage()->getQuote();
        $quote->setIsActive(0)->save();

        $quoteId = $quote->getId();

        $session->setLastQuoteId($quoteId)
            ->setLastSuccessQuoteId($quoteId)
            ->clearHelperData();

        return $this->resultPageFactory->create();
    }
}
