<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Controller\Checkout;

/**
 * Error action
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class Error extends \NordeaConnect\Magento\Controller\Checkout\Index
{
    /**
     * Execute
     *
     * @return @void
     */
    public function execute()
    {
        $message = $this->getRequest()->getParam('error_name');
        $this->messageManager->addError(__($message));

        $resultPage = $this->resultPageFactory->create();

        return $resultPage;
    }
}
