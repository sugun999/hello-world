<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Message\ManagerInterface;
use NordeaConnect\Magento\Model\Api\Transaction;

/**
 * Quote submit success observer
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class QuoteSubmitSuccessObserver implements ObserverInterface
{
    /**
     * Constructor
     *
     * @param \NordeaConnect\Magento\Model\Api\Transaction      $transaction    Transaction API model
     * @param \Magento\Framework\Message\ManagerInterface $messageManager Message manager
     *
     * @return void
     */
    public function __construct(
        Transaction $transaction,
        ManagerInterface $messageManager
    ) {
        $this->transaction = $transaction;
        $this->messageManager = $messageManager;
    }

    /**
     * Execute
     *
     * @param \Magento\Framework\Event\Observer $observer Observer object
     *
     * @return void
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $quote = $observer->getQuote();
        $order = $observer->getOrder();

        $metadata = [];
        $metadata['magento']['order']['entity_id'] = $order->getId();
        $metadata['magento']['order']['increment_id'] = $order->getIncrementId();
        $metadata['magento']['quote']['reserved_order_id'] = $quote->getReservedOrderId();

        $this->transaction->updateMetadata($quote, $metadata);
    }
}
