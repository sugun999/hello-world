define(
    [
        'ko',
        'uiComponent',
        'underscore',
        'Magento_Checkout/js/model/step-navigator',
        'Magento_Checkout/js/action/select-shipping-method',
        'Magento_Checkout/js/model/checkout-data-resolver',
        'Magento_Checkout/js/model/quote',
        'NordeaConnect_Magento/js/action/send-quote-to-psp',
        'jquery'
    ],
    function (
        ko,
        Component,
        _,
        stepNavigator,
        selectShippingMethodAction,
        checkoutDataResolver,
        quote,
        sendQuoteToPspAction,
        $
    ) {
        return Component.extend({
            defaults: {
                template: 'NordeaConnect_Magento/psp'
            },
            isVisible: ko.observable(true),
            isLoading: ko.observable(false),
            transaction: ko.observable(JSON.parse(window.checkoutConfig.quoteData.psp_transaction).href),
            initialize: function () {
                this._super();
                var self = this;

                checkoutDataResolver.resolveShippingRates([]);

                stepNavigator.registerStep(
                    'psp',
                    null,
                    '',
                    this.isVisible,
                    _.bind(this.navigate, this),
                    20
                );

                quote.totals.subscribe(function (newValue) {
                    self.reload();
                });

                this.listenToIframeResize();

                return this;
            },
            navigate: function () {
            },
            reload: function(newValue) {
                sendQuoteToPspAction(this);
            },
            listenToIframeResize: function() {
                var waitForIframe = setInterval(function() {
                    var iframe = document.querySelector("#psp-iframe");

                    if (!iframe) {
                        return;
                    }

                    clearInterval(waitForIframe);

                    window.addEventListener('message', function(msg) {
                        if (typeof msg.data !== 'object') {
                            return;
                        }
                        if (msg.data.msg === 'resize' && typeof msg.data.height === 'string') {
                            if (window.requestAnimationFrame) {
                                window.requestAnimationFrame(function() {
                                    iframe.scrolling = 'no';
                                    iframe.style.height = msg.data.height;
                                });
                            } else {
                                iframe.scrolling = 'no';
                                iframe.style.height = msg.data.height;
                            }
                        }
                    }, false);
                }, 100);
            }
        });
    }
);
