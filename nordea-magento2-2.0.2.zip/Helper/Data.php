<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Helper;

/**
 * Data helper
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * Format number
     *
     * Wrapper for number_format()
     *
     * @param float  $number             The number being formatted
     * @param int    $decimals           Sets the number of decimal points
     * @param string $decimalPoint       Sets the separator for the decimal point
     * @param string $thousandsSeparator Sets the thousands separator
     *
     * @return float
     */
    public function formatNumber($number, $decimals = 2, $decimalPoint = '.', $thousandsSeparator = '')
    {
        return number_format($number, $decimals, $decimalPoint, $thousandsSeparator);
    }

    public function formatBoolean($bool)
    {
        return $bool === true ? 'true' : 'false';
    }
}
