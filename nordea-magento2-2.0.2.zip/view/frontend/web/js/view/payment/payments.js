define([
    'uiComponent',
    'Magento_Checkout/js/model/payment/renderer-list'
], function (Component, rendererList) {
    'use strict';

    rendererList.push({
        type: 'psp_hostedwindow',
        component: 'NordeaConnect_Magento/js/view/payment/method-renderer/psp-hosted'
    });

    return Component.extend({});
});
