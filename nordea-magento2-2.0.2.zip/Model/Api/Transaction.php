<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Model\Api;

use Magento\Framework\UrlInterface;
use NordeaConnect\Magento\Helper\Iso;
use Magento\Framework\HTTP\Adapter\Curl;
use NordeaConnect\Magento\Model\Config;
use Magento\Store\Model\StoreManagerInterface;
use NordeaConnect\Magento\Helper\Data;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\ShippingMethodManagement;
use Psr\Log\LoggerInterface;

/**
 * Nordea Connect transaction API model
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class Transaction extends PaymentPsp
{
    public $resource = 'transactions';
    protected $_config = 'config';
    protected $_storeManager;
    protected $urlBuilder;
    protected $helper;
    protected $quoteRepository;

    /**
     * @var \NordeaConnect\Magento\Helper\Iso
     */
    protected $isoHelper;

    /**
     * Constructor
     *
     * @param \Magento\Framework\HTTP\Adapter\Curl          $adapter                  HTTP adapter
     * @param \NordeaConnect\Magento\Model\Config                 $config                   Config object
     * @param \Magento\Store\Model\StoreManagerInterface    $storeManager             Store manager
     * @param \Magento\Framework\UrlInterface               $urlBuilder               URL builder
     * @param \NordeaConnect\Magento\Helper\Data                  $helper                   Data helper
     * @param \Magento\Quote\Api\CartRepositoryInterface    $quoteRepository          Quote repository
     * @param \NordeaConnect\Magento\Helper\Iso                   $isoHelper                ISO helper
     * @param \Magento\Quote\Model\ShippingMethodManagement $shippingMethodManagement Shipping method management
     * @param \Psr\Log\LoggerInterface                      $logger                   Logger interface
     *
     * @return void
     */
    public function __construct(
        Curl $adapter,
        Config $config,
        StoreManagerInterface $storeManager,
        UrlInterface $urlBuilder,
        Data $helper,
        CartRepositoryInterface $quoteRepository,
        Iso $isoHelper,
        ShippingMethodManagement $shippingMethodManagement,
        LoggerInterface $logger
    ) {
        $this->_adapter = $adapter;
        $this->_config = $config;
        $this->_storeManager = $storeManager;
        $this->urlBuilder = $urlBuilder;
        $this->helper = $helper;
        $this->quoteRepository = $quoteRepository;
        $this->isoHelper = $isoHelper;
        $this->shippingMethodManagement = $shippingMethodManagement;
        $this->logger = $logger;
    }

    /**
     * Create hash
     *
     * @param Magento\Quote\Model\Quote $quote Quote object
     *
     * @return string
     */
    protected function _createHash(\Magento\Quote\Model\Quote $quote)
    {
        $hashRecipe = [
            'merchant_id' => $this->_config->getMerchantId(),
            'payment_ref' => $quote->getId(),
            'customer_ref' => $quote->getCustomerId() ? $quote->getCustomerId() : '',
            'amount' => $this->helper->formatNumber($quote->getGrandTotal()),
            'currency' => strtolower($this->_storeManager->getStore()->getCurrentCurrencyCode()),
            'test' => $this->_config->isTest() ? 'test' : '',
            'secret' => $this->_config->getSecret()
        ];

        //phpcs:disable
        $hash = md5(implode($hashRecipe));
        //phpcs:enable

        return $hash;
    }

    public function hasSentHookWithStatus($transaction, $status)
    {
        if (property_exists($transaction, 'webhooks')) {
            foreach ($transaction->webhooks as $hook) {
                if (
                    $hook->url === $this->_storeManager->getStore()->getUrl('psp/payment') &&
                    $hook->trigger === 'payment' &&
                    $hook->http_method === 'post' &&
                    $hook->data_format === 'form_data'
                ) {
                    parse_str($hook->request_body, $data);
                    if (array_key_exists('status', $data) && $data['status'] === $status) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    /**
     * Create transaction
     *
     * @param int|Magento\Quote\Model\Quote $quote A quote object or ID
     *
     * @return string
     */
    public function create($quote)
    {
        if (!is_object($quote)) {
            $quote = $this->quoteRepository->getActive($quote);
        }

        $method = 'POST';

        $webhook = [
            'url' => $this->_storeManager->getStore()->getUrl('psp/payment'),
            'trigger' => 'payment',
            'http_method' => 'post',
            'data_format' => 'form_data'
        ];

        $metaData = $this->getMetaData($quote);
        $transactionItems = $this->getItems($quote);
        $address = $quote->getBillingAddress();

        $data = [
            'merchant_id' => $this->_config->getMerchantId(),
            'amount' => $this->helper->formatNumber($quote->getGrandTotal()),
            'vat_amount' => $this->helper->formatNumber($address->getTaxAmount()),
            'payment_ref' => $quote->getId(),
            'test' => $this->_config->isTest() ? 'true' : 'false',
            'metadata' => $metaData,
            'currency' => strtolower($this->_storeManager->getStore()->getCurrentCurrencyCode()),
            'hash' => $this->_createHash($quote),
            'process' => 'false',
            'success_url' => $this->urlBuilder->getUrl('psp/checkout/redirect'),
            'error_url' => $this->urlBuilder->getUrl('psp/checkout/error'),
            'authorize' => 'true',
            'items' => json_encode($transactionItems),
            'webhook' => json_encode($webhook),
            'payment_details' => $metaData['user']
        ];

        if ($quote->getCustomerId()) {
            $data['customer_ref'] = $quote->getCustomerId();
        }

        return $this->call($method, $this->resource, null, $data);
    }

    /**
     * Update transaction
     *
     * @param int|Magento\Quote\Model\Quote $quote A quote object or ID
     *
     * @return string|boolean
     */
    public function update($quote)
    {
        if (!is_object($quote)) {
            $quote = $this->quoteRepository->getActive($quote);
        }

        $transaction = json_decode($quote->getPspTransaction());

        if (property_exists($transaction, 'id')) {
            $id = $transaction->id;
        } else {
            return false;
        }

        $method = 'PUT';

        $metaData = $this->getMetaData($quote);
        $transactionItems = $this->getItems($quote);
        $address = $quote->getBillingAddress('shipping');

        $data = [
            'amount' => $this->helper->formatNumber($quote->getGrandTotal()),
            'vat_amount' => $this->helper->formatNumber($address->getTaxAmount()),
            'metadata' => $metaData,
            'currency' => strtolower($this->_storeManager->getStore()->getCurrentCurrencyCode()),
            'hash' => $this->_createHash($quote),
            'items' => json_encode($transactionItems),
            'process' => 'false',
            'payment_details' => $metaData['user']
        ];

        if ($quote->getCustomerId()) {
            $data['customer_ref'] = $quote->getCustomerId();
        }

        return $this->call($method, $this->resource, (string) $id, $data);
    }

    /**
     * Update metadata
     *
     * @param int|Magento\Quote\Model\Quote $quote    A quote object or ID
     * @param array                         $metadata An array with metadata
     * @param boolean                       $merge    Whether or not to merge with existing metadata
     *
     * @return string|boolean
     */
    public function updateMetadata($quote, $metadata, $merge = true)
    {
        if (!is_object($quote)) {
            $quote = $this->quoteRepository->get($quote);
        }

        $transaction = json_decode($quote->getPspTransaction());

        if (!is_object($transaction)) {
            return false;
        }

        if (property_exists($transaction, 'id')) {
            $id = $transaction->id;
        } else {
            return false;
        }

        $data = [];

        if ($merge) {
            $transaction = $this->show($id);

            $transaction = json_decode($transaction, true);

            if (array_key_exists('metadata', $transaction)) {
                $existingMetaData = $transaction['metadata'];
                $data['metadata'] = array_merge_recursive($existingMetaData, $metadata);
            } else {
                $data['metadata'] = $metadata;
            }
        } else {
            $data['metadata'] = $metadata;
        }

        $data['process'] = 'false';
        
        $method = 'PUT';

        return $this->call($method, $this->resource, (string) $id, $data);
    }

    /**
     * Capture transaction
     *
     * @param \Magento\Sales\Model\Order $order  Order
     * @param float                      $amount Amount to capture
     *
     * @return string|boolean
     */
    public function capture(\Magento\Sales\Model\Order $order, $amount)
    {
        $method = 'PUT';

        $transaction = json_decode($order->getPspTransaction());

        if (property_exists($transaction, 'id')) {
            $id = $transaction->id;
        } else {
            return false;
        }

        // Assure remote transaction only is reserved
        $currentTransactionJson = $this->show($id);
        $currentTransaction = json_decode($currentTransactionJson);

        if (is_object($currentTransaction) && property_exists($currentTransaction, 'status')) {
            switch ($currentTransaction->status) {
                case 'approved':
                    return $currentTransactionJson;
                case 'authorized':
                    return $this->call($method, $this->resource, [$id, 'capture'], [
                        'amount' => $this->helper->formatNumber($amount * $order->getBaseToOrderRate())
                    ]);
                default:
                    return false;
            }
        }

        return false;
    }

    /**
     * Refund transaction
     *
     * @param \Magento\Sales\Model\Order $order  Order
     * @param float                      $amount Amount to capture
     *
     * @return string
     */
    public function refund(\Magento\Sales\Model\Order $order, $amount)
    {
        $method = 'POST';

        $transaction = json_decode($order->getPspTransaction());

        if (property_exists($transaction, 'id')) {
            $id = $transaction->id;
        } else {
            return false;
        }

        $data = [
            'amount' => $this->helper->formatNumber($amount * $order->getBaseToOrderRate()),
            'reason' => 'Refund from Magento',
            'transaction_id' => $id
        ];

        return $this->call($method, 'refunds', null, $data);
    }

    /**
     * Show transaction
     *
     * @param int $id Transaction ID
     *
     * @return string
     */
    public function show($id)
    {
        $method = 'GET';

        return $this->call($method, $this->resource, (string) $id);
    }

    /**
     * Get items
     *
     * @param Magento\Quote\Model\Quote $quote A quote object
     *
     * @return array
     */
    protected function getItems($quote)
    {
        $quoteItems = $quote->getAllVisibleItems();

        $transactionItems = [];

        foreach ($quoteItems as $item) {
            $transactionItems[] = [
                'artno' => $item->getSku(),
                'description' => $item->getName(),
                'qty' => $item->getQty(),
                'amount' => $this->helper->formatNumber(
                    $item->getRowTotalInclTax() - $item->getDiscountAmount()
                ),
                'vat' => $this->helper->formatNumber($item->getTaxPercent()),
                'discount' => $this->helper->formatNumber($item->getDiscountAmount())
            ];
        }

        if (!$quote->isVirtual()) {
            $shippingAddress = $quote->getShippingAddress('shipping');
            $shippingAmount = $shippingAddress->getShippingAmount();

            if ($shippingAmount > 0) {
                $shippingVat = (
                    1 - ($shippingAmount - $shippingAddress->getShippingTaxAmount()) / $shippingAmount
                    ) * 100;
            } else {
                $shippingVat = 0;
            }

            $transactionItems[] = [
                'artno' => $shippingAddress->getShippingMethod(),
                'description' => $shippingAddress->getShippingDescription(),
                'qty' => 1,
                'amount' => $this->helper->formatNumber($shippingAddress->getShippingInclTax()),
                'vat' => $this->helper->formatNumber($shippingVat),
                'discount' => $this->helper->formatNumber($shippingAddress->getShippingDiscountAmount())
            ];
        }

        return $transactionItems;
    }

    /**
     * Get meta data
     *
     * @param Magento\Quote\Model\Quote $quote A quote object
     *
     * @return array
     */
    protected function getMetaData($quote)
    {
        $shippingMethods = $this->shippingMethodManagement->getList($quote->getId());

        $shippingData = [];

        foreach ($shippingMethods as $shippingMethod) {
            $shippingData[] = [
                'carrier_code' => $shippingMethod->getCarrierCode(),
                'method_code' => $shippingMethod->getMethodCode(),
                'carrier_title' => $shippingMethod->getCarrierTitle(),
                'method_title' => $shippingMethod->getMethodTitle(),
                'amount' => $shippingMethod->getAmount(),
                'base_amount' => $shippingMethod->getBaseAmount(),
                'available' => $shippingMethod->getAvailable(),
                'error_message' => $shippingMethod->getErrorMessage(),
                'price_excl_tax' => $shippingMethod->getPriceExclTax(),
                'getPriceInclTax' => $shippingMethod->getPriceInclTax()
            ];
        }

        $allowedCountries = $this->_config->getAllowedCountries();
        $defaultCountry = $this->_config->getDefaultCountry();

        $shippingAddress = $quote->getShippingAddress();
        $billingAddress = $quote->getBillingAddress();

        if ($this->_config->getPaymentMode() === 'checkout' && !$billingAddress->getCountryId()) {
            $billingAddress = $shippingAddress;
        }

        return [
            'user' => [
                'email' => $billingAddress->getEmail(),
                'phone' => $billingAddress->getTelephone(),
                'first_name' => $billingAddress->getFirstname(),
                'last_name' => $billingAddress->getLastname(),
                'zip' => $billingAddress->getPostcode(),
                'address_1' => $billingAddress->getStreetLine(1),
                'address_2' => $billingAddress->getStreetLine(2),
                'city' => $billingAddress->getCity(),
                'country_code' => $this->isoHelper->transform($billingAddress->getCountryId())
            ],
            'shipping' => [
                'email' => $shippingAddress->getEmail(),
                'phone' => $shippingAddress->getTelephone(),
                'first_name' => $shippingAddress->getFirstname(),
                'last_name' => $shippingAddress->getLastname(),
                'zip' => $shippingAddress->getPostcode(),
                'address_1' => $shippingAddress->getStreetLine(1),
                'address_2' => $shippingAddress->getStreetLine(2),
                'city' => $shippingAddress->getCity(),
                'country_code' => $this->isoHelper->transform($shippingAddress->getCountryId())
            ],
            'products' => $this->getItems($quote),
            'magento' => [
                'edition' => $this->_config->getMagentoEdition(),
                'version' => $this->_config->getMagentoVersion(),
                'php' => phpversion(),
                'module' => $this->_config->getModuleInformation(),
                'configuration' => [
                    'general' => [
                        'country' => [
                            'allow' => $allowedCountries,
                            'default' => $defaultCountry
                        ]
                    ]
                ],
                'shipping_methods' => $shippingData,
                'quote' => [
                    'entity_id' => $quote->getId()
                ]
            ],
            'checkoutMode' => $this->helper->formatBoolean($this->_config->getPaymentMode() === 'checkout'),
            'settings' => [
                'payment_mode' => $this->_config->getPaymentMode(),
                'payment_view' => $this->_config->getPaymentView(),
            ],
        ];
    }
}
