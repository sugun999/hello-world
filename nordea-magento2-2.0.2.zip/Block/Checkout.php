<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Block;

/**
 * Checkout block
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class Checkout extends \Magento\Checkout\Block\Onepage
{
    //phpcs:disable
    /**
     * Constructor
     *
     * @param \Magento\Framework\View\Element\Template\Context $context          Context
     * @param \Magento\Framework\Data\Form\FormKey             $formKey          Form key
     * @param \Magento\Checkout\Model\CompositeConfigProvider  $configProvider   Config provider
     * @param array                                            $layoutProcessors Array with layout processors
     * @param array                                            $data             Array with data
     *
     * @return void
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\Data\Form\FormKey $formKey,
        \Magento\Checkout\Model\CompositeConfigProvider $configProvider,
        array $layoutProcessors = [],
        array $data = []
    ) {
        parent::__construct($context, $formKey, $configProvider, $layoutProcessors, $data);
    }
    //phpcs:enable
}
