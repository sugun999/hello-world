<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Controller\Payment;

use NordeaConnect\Magento\Helper\Iso;
use NordeaConnect\Magento\Model\Api\Transaction;
use NordeaConnect\Magento\Model\Api\Customer;
use NordeaConnect\Magento\Helper\Data;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Api\CartManagementInterface;
use Magento\Sales\Model\Order;
use Magento\Newsletter\Model\Subscriber;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Webapi\Exception as WebapiException;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Phrase;
use Psr\Log\LoggerInterface;

/**
 * Payment action
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class Index extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $logger;

    /**
     * @var \Magento\Quote\Api\CartRepositoryInterface
     */
    protected $quoteRepository;

    /**
     * @var \Magento\Quote\Api\CartManagementInterface
     */
    protected $quoteManagement;

    /**
     * @var \NordeaConnect\Magento\Helper\Iso
     */
    protected $isoHelper;

    /**
     * @var \NordeaConnect\Magento\Model\Api\Transaction
     */
    protected $transaction;

    /**
     * @var \NordeaConnect\Magento\Model\Api\Customer
     */
    protected $customer;

    /**
     * @var \NordeaConnect\Magento\Helper\Data
     */
    protected $helper;

    /**
     * @var \Magento\Sales\Model\Order
     */
    protected $order;

    /**
     * @var \Magento\Newsletter\Model\Subscriber
     */
    protected $subscriber;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $transportBuilder;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    protected $invoiceService;
    protected $transactionFactory;
    protected $store;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Action\Context               $context           Context object
     * @param \Magento\Framework\Controller\Result\JsonFactory    $resultJsonFactory Result factory
     * @param \Psr\Log\LoggerInterface                            $logger            Logger interface
     * @param \Magento\Quote\Api\CartRepositoryInterface          $quoteRepository   Cart repository interface
     * @param \Magento\Quote\Api\CartManagementInterface          $quoteManagement   Cart management interface
     * @param \NordeaConnect\Magento\Helper\Iso                         $isoHelper         ISO helper
     * @param \NordeaConnect\Magento\Model\Api\Transaction        $transaction       Transaction API model
     * @param \NordeaConnect\Magento\Model\Api\Customer           $customer          Customer API model
     * @param \NordeaConnect\Magento\Helper\Data                  $helper            Data helper
     * @param \Magento\Sales\Model\Order                          $order             Order model
     * @param \Magento\Newsletter\Model\Subscriber                $subscriber        Subscriber model
     * @param \Magento\Framework\Mail\Template\TransportBuilder   $transportBuilder  Transport builder
     * @param \Magento\Framework\App\Config\ScopeConfigInterface  $scopeConfig       Scope config
     *
     * @return void
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        LoggerInterface $logger,
        CartRepositoryInterface $quoteRepository,
        CartManagementInterface $quoteManagement,
        Iso $isoHelper,
        Transaction $transaction,
        Customer $customer,
        Data $helper,
        Order $order,
        Subscriber $subscriber,
        TransportBuilder $transportBuilder,
        ScopeConfigInterface $scopeConfig,
        \Magento\Sales\Model\Service\InvoiceService $invoiceService,
        \Magento\Framework\DB\TransactionFactory $transactionFactory,
        \Magento\Store\Model\StoreManagerInterface $store
    ) {
        parent::__construct($context);

        $this->resultJsonFactory = $resultJsonFactory;
        $this->logger = $logger;
        $this->quoteRepository = $quoteRepository;
        $this->quoteManagement = $quoteManagement;
        $this->isoHelper = $isoHelper;
        $this->transaction = $transaction;
        $this->customer = $customer;
        $this->helper = $helper;
        $this->order = $order;
        $this->subscriber = $subscriber;
        $this->transportBuilder = $transportBuilder;
        $this->scopeConfig = $scopeConfig;

        $this->invoiceService = $invoiceService;
        $this->transactionFactory = $transactionFactory;
        $this->store = $store;
    }

    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        $result = $this->resultJsonFactory->create();

        $this->logger->debug('payment hook received', [
            'context' => 'payment_hook',
            'data' => $data,
        ]);

        try {
            $this->validateHookData($data);
            $quote = $this->getQuote($data['payment_ref'], $data['id']);

            if ($quote->getIsActive()) {
                $this->logger->debug('Quote is still active', [
                    'context' => 'payment_hook',
                    'quote_id' => $quote->getId(),
                    'transaction_id' => $data['id']
                ]);

                return $result->setHttpResponseCode(WebapiException::HTTP_INTERNAL_ERROR)->setData([
                    'status' => 'noop',
                    'message' => 'Quote is still active',
                    'details' => ['quote_id' => $quote->getId()],
                ]);
            }

            $trx = $this->getTransaction($data['id']);

            switch ($data['status']) {
                // - Approved hook: hook that has status approved in its request data
                // - Authorized hook: hook that has status authorized in its request data
                //
                // Approved hook should not be handled if a authorized hook was already received.
                // When the authroized hook is received and the option for auto capture is enabled
                // then magento captures the order in the order save method.
                // Our capture method sends a capture request to the backend that, and that results in a new approved hook.
                // If that hook is sent before magento is done with saving the order then the new hook will create a new order
                // with from the same quote.
                //
                // If the transaction is already captured in the backend (e.g swish payment) then there will be no authorized hook
                // and the approved hook has to be handled as a authorized hook.
                case 'approved':
                    if ($this->transaction->hasSentHookWithStatus($trx, 'authorized')) {
                        $this->logger->debug('Order is already in progress', [
                            'context' => 'payment_hook',
                            'quote_id' => $quote->getId(),
                            'transaction_id' => $trx->id
                        ]);
                        return $result->setData([
                            'status' => 'noop',
                            'message' => 'Order already in progress',
                            'details' => ['quote_id' => $quote->getId()],
                        ]);
                    }
                case 'authorized':
                    return $result->setData($this->createOrder($quote, $trx));
                default:
                    $this->logger->debug('Unknown status', [
                        'context' => 'payment_hook',
                        'status' => $data['status'],
                        'transaction_id' => $trx->id
                    ]);

                    return $result->setData([
                        'status' => 'noop',
                        'message' => 'Unknown status',
                        'details' => ['status' => $data['status']]
                    ]);
            }
        } catch (\Exception $exception) {
            $message = $exception->getMessage();
            $details = ['quote_id' => $quote->getId(), 'transaction_id' => $data['id']];
            $statusCode;

            $mailMessage = "Quote %1 could not be converted to an order. Please make sure the Nordea Connect transaction %2 contains valid order information. \n\n%3";

            switch (get_class($exception)) {
                case WebapiException::class:
                    $message = $exception->getCode();
                    $details = array_merge($exception->getDetails(), $details);
                    $statusCode = $exception->getHttpCode();
                    break;
                case LocalizedException::class:
                    $statusCode = WebapiException::HTTP_BAD_REQUEST;
                    break;
                default:
                    $statusCode = WebapiException::HTTP_INTERNAL_ERROR;
                    $mailMessage = "Quote %1 could not be converted to an order. Transaction id %2 from Nordea Connect.\n\n%3";
            }

            $this->logger->error($message, [
                'context' => 'payment_hook',
                'exception' => $exception,
                'details' => $details,
            ]);

            $this->sendErrorMessage(new Phrase($mailMessage, [$quote->getId(), $data['id'], $exception->getMessage()]));

            return $result->setHttpResponseCode($statusCode)->setData([ 'status' => 'error', 'message' => $message, 'details' => $details, ]);
        }
    }

    private function validateHookData($data)
    {
        $missingFields = array_diff(['id', 'payment_ref', 'status', 'amount'], array_keys($data));

        if (count($missingFields)) {
            throw new WebapiException(
                new Phrase('Invalid fields in transaction, missing: %1', [implode(',', $missingFields)]),
                'invalid fields',
                WebapiException::HTTP_BAD_REQUEST,
                ['missing' => $missingFields]
            );
        }

        return;
    }

    private function getQuote($quoteId, $trxId)
    {
        $quote = $this->quoteRepository->get($quoteId);
        if ($quote->getIsActive()) {
            $timeout = (new \DateTime($quote->getUpdatedAt()))->add(new \DateInterval('PT5M'));
            if (new \DateTime() > $timeout) {
                $quote->setIsActive(0)->save();
            }
        }

        return $quote;
    }

    private function validateAmount($trxAmount, $quoteAmount, $trxId, $quoteId)
    {
        $quoteAmount = $this->helper->formatNumber($quoteAmount);

        if ((float) $trxAmount !== (float) $quoteAmount) {
            throw new WebapiException(
                new Phrase(
                    "Quote has different amount than the transaction. Quote amount: %1. Transaction amount: %2.",
                    [$quoteAmount, $trxAmount]
                ),
                'diff in amount',
                WebapiException::HTTP_BAD_REQUEST,
                ['transaction_amount' => $trxAmount, 'quote_amount' => $quoteAmount]
            );
        }
    }

    private function createOrder($quote, $trx)
    {
        $existingOrderId = $this->order->loadByAttribute('quote_id', $quote->getId())->getIncrementId();

        if ($existingOrderId) {
            $this->logger->debug('Order already exists', [
                'context' => 'payment_hook',
                'quote_id' => $quote->getId(),
                'order_id' => $existingOrderId,
                'transaction_id' => $trx->id,
            ]);

            return [
                'status' => 'noop',
                'message' => 'Order already exists',
                'details' => [
                    'quote_id' => $quote->getId(),
                    'order_id' => $existingOrderId,
                ],
            ];
        }

        $this->validateAmount($trx->amount, $quote->getGrandTotal(), $trx->id, $quote->getId());
        $this->store->getStore()->setCurrentCurrencyCode($trx->currency);

        if ($trx->transaction_type == 'invoice' ||
            (!empty($trx->metadata->settings->payment_mode) && $trx->metadata->settings->payment_mode === 'checkout')
        ) {
            $shippingAddress = $quote->getShippingAddress();
            $shippingAddress->setFirstname($trx->payment_details->first_name);
            $shippingAddress->setLastname($trx->payment_details->last_name);
            $shippingAddress->setStreet([$trx->payment_details->address_1, $trx->payment_details->address_2 ]);
            $shippingAddress->setCity($trx->payment_details->city);
            $shippingAddress->setPostcode($trx->payment_details->zip);
            $shippingAddress->setTelephone($trx->payment_details->phone ?: '0');
            if (!empty($trx->payment_details->email)) {
                $shippingAddress->setEmail($trx->payment_details->email);
            }
            $shippingAddress->setCountryId($this->isoHelper->convertFromAlpha3($trx->payment_details->country_code));
            $shippingAddress->save();
        }

        $billingAddress = $quote->getBillingAddress();
        $billingAddress->setFirstname($trx->payment_details->first_name);
        $billingAddress->setLastname($trx->payment_details->last_name);
        $billingAddress->setStreet([$trx->payment_details->address_1, $trx->payment_details->address_2]);
        $billingAddress->setCity($trx->payment_details->city);
        $billingAddress->setPostcode($trx->payment_details->zip);
        $billingAddress->setTelephone($trx->payment_details->phone ?: '0');
        if (!empty($trx->payment_details->email)) {
            $billingAddress->setEmail($trx->payment_details->email);
        }
        $billingAddress->setCountryId($this->isoHelper->convertFromAlpha3($trx->payment_details->country_code));
        $billingAddress->save();

        $quote->getPayment()->importData(['method' => 'psp_hostedwindow']);
        $quote->getPayment()->setAdditionalInformation('id', $trx->id);
        $quote->getPayment()->setAdditionalInformation('href', $trx->href);
        $quote->getPayment()->setAdditionalInformation('status', $trx->status);

        $quote->save();

        $quote->setCustomerEmail($quote->getBillingAddress()->getEmail());

        if (!is_object($trx->customer) || !property_exists($trx->customer, 'id')) {
            $quote->setCheckoutMethod('guest');
            $quote->setCustomerId(null);
            $quote->setCustomerIsGuest(true);
            $quote->setCustomerGroupId(\Magento\Customer\Api\Data\GroupInterface::NOT_LOGGED_IN_ID);
        }

        $metadata = $trx->metadata;
        if (property_exists($metadata, 'newsletter') && $metadata->newsletter === true) {
            if (property_exists($trx, 'customer_ref') && $trx->customer_ref) {
                $this->subscriber->subscribeCustomerById($trx->customer_ref);
            } elseif (property_exists($metadata, 'email') && $metadata->email) {
                $this->subscriber->subscribe($metadata->email);
            }
        }

        $order = $this->quoteManagement->submit($quote);

        if ($trx->status === 'approved') {
            $this->createInvoice($order, $trx);
        }

        $this->logger->debug('Order created', [
            'context' => 'payment_hook',
            'quote_id' => $quote->getId(),
            'order_id' => $order->getIncrementId(),
            'transaction_id' => $trx->id,
        ]);

        $this->_eventManager->dispatch('checkout_submit_all_after', ['order' => $order, 'quote' => $quote]);

        return [
            'status' => 'success',
            'message' => 'Order was created',
            'details' => [
                'quote_id' => $quote->getId(),
                'order_id' => $order->getIncrementId()
            ]
        ];
    }

    private function getTransaction($trxId)
    {
        $trx = json_decode($this->transaction->show($trxId));
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new WebapiException(
                new Phrase('Invalid transaction response'),
                'invalid response data',
                WebapiException::HTTP_BAD_REQUEST,
                ['json_error' => json_last_error_msg()]
            );
        }
        return $trx;
    }

    private function sendErrorMessage($message)
    {
        if ($this->scopeConfig->getValue(
            'payment/psp/email_webhook_failures_to',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        )) {
            $emailData = new \Magento\Framework\DataObject();
            $emailData->setData(['notice' => $message->render()]);

            $this
                ->transportBuilder
                ->setTemplateIdentifier('psp_payment_webhook_notice')
                ->setTemplateOptions([
                    'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                    'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID,
                ])
                ->setTemplateVars(['data' => $emailData])
                ->setFrom([
                    'email' => $this->scopeConfig->getValue(
                        'trans_email/ident_support/email',
                        \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                    ),
                    'name' => $this->scopeConfig->getValue(
                        'trans_email/ident_support/name',
                        \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                    )
                ])
                ->addTo($this->scopeConfig->getValue(
                    'payment/psp/email_webhook_failures_to',
                    \Magento\Store\Model\ScopeInterface::SCOPE_STORE
                ))
                ->getTransport()
                ->sendMessage();
        }
    }

    private function createInvoice($order, $trx)
    {
        if($order->canInvoice()) {
            $invoice = $this->invoiceService->prepareInvoice($order);
            $invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_ONLINE);
            $invoice->setTransactionId($trx->id)->setIsTransactionClosed(false);
            $invoice->setAdditionalInformation('id', $trx->id);
            $invoice->setAdditionalInformation('href', $trx->href);
            $invoice->setAdditionalInformation('status', $trx->status);
            $invoice->register();
            $invoice->getOrder()->setCustomerNoteNotify(false);
            $invoice->getOrder()->setIsInProcess(true);

            $order->addStatusHistoryComment(__('Automatically INVOICED'), false);
            $transactionSave = $this->transactionFactory->create()->addObject($invoice)->addObject($invoice->getOrder());
            $transactionSave->save();
        }
    }
}
