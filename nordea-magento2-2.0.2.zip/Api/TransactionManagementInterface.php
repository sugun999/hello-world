<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Api;

/**
 * Transaction management interface
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
interface TransactionManagementInterface
{
    /**
     * @param int $cartId Quote identifier
     *
     * @return string
     */
    public function update($cartId);
}
