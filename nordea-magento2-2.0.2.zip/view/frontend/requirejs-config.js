var config = {
    map: {
        '*': {
            iframeResizer: 'NordeaConnect_Magento/js/iframeResizer'
        }
    },
    shim: {
        iframeResizer: ['jquery']
    }
};