<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Plugin\Block\Onepage;

use Magento\Framework\UrlInterface;
use NordeaConnect\Magento\Model\Config;

/**
 * Onepage link block plugin
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class Link
{
    protected $urlBuilder;
    protected $config;

    /**
     * Constructor
     *
     * @param \Magento\Framework\UrlInterface $urlBuilder URL builder
     * @param \NordeaConnect\Magento\Model\Config   $config     Config model
     */
    public function __construct(UrlInterface $urlBuilder, Config $config)
    {
        $this->urlBuilder = $urlBuilder;
        $this->config = $config;
    }

    /**
     * After getCheckoutUrl()
     *
     * @param \Magento\Checkout\Block\Onepage\Link $subject Checkout cart block
     * @param string                               $result  The original result from the method in $subject
     * @return string
     */
    public function afterGetCheckoutUrl(\Magento\Checkout\Block\Onepage\Link $subject, $result)
    {
        if (!$this->config->isCheckoutActive()) {
            return $result;
        }

        return $this->urlBuilder->getUrl('psp/checkout');
    }
}
