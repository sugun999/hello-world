<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * Install schema
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * Install
     *
     * @param Magento\Framework\Setup\SchemaSetupInterface   $setup   Schema setup interface
     * @param Magento\Framework\Setup\ModuleContextInterface $context Module context interface
     *
     * @return void
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        $tables = [
            $installer->getTable('quote'),
            $installer->getTable('sales_order'),
            $installer->getTable('sales_order_grid')
        ];

        foreach ($tables as $table) {
            $installer->getConnection()->addColumn(
                $table,
                'psp_transaction',
                [
                    'type'     => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'length'   => '64k',
                    'unsigned' => true,
                    'nullable' => true,
                    'comment'  => 'Nordea Connect Transaction'
                ]
            );
        }

        $installer->endSetup();
    }
}
