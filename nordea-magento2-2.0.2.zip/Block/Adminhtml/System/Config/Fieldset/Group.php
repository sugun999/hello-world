<?php
/**
 * Nordea Connect
 *
 * PHP version 5.6
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */

namespace NordeaConnect\Magento\Block\Adminhtml\System\Config\Fieldset;

/**
 * Fieldset group block
 *
 * @category Nordea Connect
 * @package  NordeaConnect_Magento
 * @author   Nordea Connect <>
 * @license  MIT License https://opensource.org/licenses/MIT
 * @link     www.nordeaconnect.com
 */
class Group extends \Magento\Config\Block\System\Config\Form\Fieldset
{
    //phpcs:disable
    /**
     * Constructor
     *
     * @param \Magento\Backend\Block\Context      $context     Context
     * @param \Magento\Backend\Model\Auth\Session $authSession Auth session
     * @param \Magento\Framework\View\Helper\Js   $jsHelper    Javascript helper
     * @param array                               $data        Data
     *
     * @return void
     */
    public function __construct(
        \Magento\Backend\Block\Context $context,
        \Magento\Backend\Model\Auth\Session $authSession,
        \Magento\Framework\View\Helper\Js $jsHelper,
        array $data = []
    ) {
        parent::__construct($context, $authSession, $jsHelper, $data);
    }
    //phpcs:enable

    /**
     * Is collapse state
     *
     * @param \Magento\Framework\Data\Form\Element\AbstractElement $element Element
     *
     * @return bool
     */
    protected function _isCollapseState($element)
    {
        $extra = $this->_authSession->getUser()->getExtra();
        if (isset($extra['configState'][$element->getId()])) {
            return $extra['configState'][$element->getId()];
        }

        $groupConfig = $element->getGroup();
        if (!empty($groupConfig['expanded'])) {
            return true;
        }

        return false;
    }
}
